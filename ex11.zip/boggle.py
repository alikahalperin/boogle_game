from typing import Callable
from ex11_GUI import BoggletGui
from ex11_model import BoggleModel
from playsound import playsound
from ex11_utils import*
class BoggleController:
    def __init__(self,words_dict) -> None:
        self._gui = BoggletGui()
        self._model = BoggleModel(words_dict)
        self.get_btns()

    def get_btns(self) -> None :
        '''
        the function gets the board nuttons from GUI Class
        and sets them a command
        '''
        for button_tuple in self._gui.get_buttons_locs():
            action = self.create_button_action(button_tuple)
            self._gui.set_button_command(button_tuple[1],action)

    def create_button_action(self,button_tuple) -> Callable :
        '''
        defines a function that will be the action of the pressed button 
        if the pressed button does not start a new game it calles the function type in from the model
        and set_display from the gui with the returned values of the function get display from the model
        if the pressed button does start a new game, it also starts a new game
        '''
        def fun():
            self._model.type_in(button_tuple)
            self._gui.set_display(self._model.get_display(button_tuple[1]))
            if button_tuple[1]==(4,1):
                self.start_new_game()
        return fun

    def run(self)-> None:
        '''
        runs the program
        '''
        self._gui.run()

    def start_new_game(self)-> None:
        '''
        gets new board and buttons from the GUI
        '''
        self.get_btns()

if __name__ == "__main__":
    file_name = "boggle_dict.txt"
    words_dict = load_words_dict(file_name)
    BoggleController(words_dict).run()