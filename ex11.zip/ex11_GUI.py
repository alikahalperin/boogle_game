import tkinter as tk
import math
from boggle_board_randomizer import*
from typing import*
from PIL import Image, ImageTk
WIDTH = 1440
HEIGHT = 720
MAIN_COLOR = "brown4"
MAIN_FONT = 'Times'

class BoggletGui:
    _buttons = [] #list[list[Button]]
    _pressed_buttons = [] #list[list[Button]]
    _last_pressed = None
    def __init__(self) -> None:
        root = tk.Tk()
        root.configure(bg=MAIN_COLOR)
        root.geometry('1440x720')
        root.title("boggle")
        root.resizable(False,False)
        self._main_window=root
        self._timer =181000

        def height_pr(percentage):
            '''
            function that calculates percentage of height
            '''
            return HEIGHT/100*percentage
        def width_pr(percentage):
            '''
            function that calculates percentage of height
            '''
            return WIDTH/100*percentage

        #create and place four main frames 
        self._top_frame = tk.Frame(root,width=WIDTH,height=height_pr(20),bg=MAIN_COLOR)
        self._top_frame.place(x=0,y=0)
        
        self._left_frame = tk.Frame(root, bg=MAIN_COLOR,width=width_pr(23),height=height_pr(67),highlightbackground="blanched almond",highlightthickness=5)
        self._left_frame.place(x=15,y=height_pr(25))
        
        self._right_frame = tk.Frame(root, bg=MAIN_COLOR,width=width_pr(25),height=height_pr(75))
        self._right_frame.place(x=width_pr(75),y=height_pr(25))
        
        self._center_frame = tk.Frame(root,bg=MAIN_COLOR, width=width_pr(50),height=height_pr(80))
        self._center_frame.place(x=width_pr(25), y=height_pr(20)-14)
        
        #create main Labels in each Frame
        # in LEFT FRAME LABELS 
        self._display_words_label=tk.Label(self._left_frame,text='THE WORDS YOU FOUND',bg=MAIN_COLOR,fg="peach puff",font=(MAIN_FONT, 18))
        self._display_words_label.place(relx=0.5, rely=0.04, anchor="center")

        self.words_box_label = tk.Label(self._left_frame)
        self.words_box_label.place (relx=0.5, rely=0.55, anchor="center")

        # in RIGHT FRAME LABELS 
        #SCORE TEXT
        self._display_score_label=tk.Label(self._right_frame,text='YOUR SCORE: 0',bg=MAIN_COLOR,fg="peach puff",font=(MAIN_FONT, 18))
        self._display_score_label.place(relx=0.3, rely=0.05, anchor="center")
        #TIME TEXT
        self._display_time_label=tk.Label(self._right_frame,text='TIME LEFT:',bg=MAIN_COLOR,fg="peach puff",font=(MAIN_FONT, 18))
        self._display_time_label.place(relx=0.3, rely=0.25, anchor="center")
        #START GAME BTN
        self._countdown_button = tk.Button(self._right_frame, text="START GAME!", bg="peach puff",font=(MAIN_FONT,16),width=15,height=2,highlightbackground="maroon",highlightthickness=1)
        self._countdown_button.place(relx=0.3, rely=0.44, anchor="center")
        self._countdown_button.bind("<Button-1>", lambda event : self._start_play())
        #TIMER
        self._countdown_timer_minutes = tk.Label(self._right_frame,text="03:", bg=MAIN_COLOR,fg="peach puff", font=(MAIN_FONT, 27))
        self._countdown_timer_minutes.place(relx=0.23, rely=0.33, anchor="center")
        self._countdown_timer_seconds = tk.Label(self._right_frame,text="00", bg=MAIN_COLOR,fg="peach puff", font=(MAIN_FONT, 27))
        self._countdown_timer_seconds.place(relx=0.35, rely=0.33, anchor="center")
        #CHECK MY WORD BUTTON
        self._check_button = tk.Button(self._right_frame,text="CHECK MY WORD",bg="peach puff",font=(MAIN_FONT,16),width=15,height=2,highlightbackground="maroon",highlightthickness=1)
        self._check_button.pack()
        self._check_button.place(relx=0.3, rely=0.77, anchor="center")
        #DISPLAY FEEDBACK LABEL
        self._display_feedback_label=tk.Label(self._right_frame,text="",bg=MAIN_COLOR,fg="peach puff", font=("Times",20))
        self._display_feedback_label.place(relx=0.3, rely=0.53, anchor="center")
        # in CENTER FRAME LABELS 
        self._board_label=tk.Label(self._center_frame)
        self._board_label.place(relx=0.5, rely=0.45, anchor="center")
        #YOUR WORD DISPLAY
        self._display_word_label=tk.Label(self._center_frame,text="YOUR WORD: ",bg=MAIN_COLOR,fg="peach puff", font=("Times",20))
        self._display_word_label.place(relx=0.4, rely=0.97, anchor="center")
        #SCROLLBAR
        self._scrollbar = tk.Scrollbar(self.words_box_label,bg="peach puff",troughcolor=MAIN_COLOR,)
        self._scrollbar.pack( side = "right", fill = "y" )
        #LISTBOX
        self._words_list = tk.Listbox(self.words_box_label, yscrollcommand = self._scrollbar.set,bg=MAIN_COLOR,fg="peach puff",font=(MAIN_FONT, 18),justify="center",width=25,height=16)
        self._words_list.pack( side = "left", fill = "both" )
        self._scrollbar.config( command = self._words_list.yview )
        #HEADING IMG
        image = Image.open("heading.png")
        photo = ImageTk.PhotoImage(image.resize((600,120), Image.ANTIALIAS))
        self._image_label = tk.Label(self._top_frame, image=photo,bg= MAIN_COLOR)
        self._image_label.image = photo
        self._image_label.place(relx=0.5, rely=0.5, anchor="center")
        #CREATE BUTTONS
        self._create_buttons_in_board()
        self._sheet = tk.Canvas(self._center_frame,width=width_pr(50),height=height_pr(80),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
        self._sheet.pack()
        #YES BUTTON
        self.yes_button = tk.Button(self._right_frame, text="YES",bg="peach puff",font=(MAIN_FONT,16),width=5,height=2)
        self.yes_button.place(relx=0.15, rely=0.62, anchor="center")
        self._buttons[4][1]= self.yes_button
        #NO BUTTON
        self.no_button = tk.Button(self._right_frame, text="NO",bg="peach puff",font=(MAIN_FONT,16),width=5,height=2)
        self.no_button.bind("<Button-1>", lambda event : self._finish_game())
        self.no_button.place(relx=0.45, rely=0.62, anchor="center")
        self._buttons[4][2]= self.no_button
        #HIDE BOARD AND CHECK BUTTON AT THE BGUINING OF THE GAME
        self._hide_new_game = tk.Canvas(self._right_frame,width=width_pr(15),height=height_pr(10),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
        self._hide_new_game.place(relx=0.3, rely=0.62, anchor="center")
        self._hide_check_button2 = tk.Canvas(self._right_frame,width=self.width_pr(15),height=self.height_pr(10),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
        self._hide_check_button2.place(relx=0.3, rely=0.77, anchor="center")

    def height_pr(self, percentage):
            '''
            function that calculates percentage of height
            '''
            return HEIGHT/100*percentage
    def width_pr(self, percentage):
            '''
            function that calculates percentage of height
            '''
            return WIDTH/100*percentage

    def _finish_game(self):
        '''
        the function exits the game
        '''
        self._main_window.destroy()
        return True
    
  
    def _start_play(self):
        '''
        when a game starts this function destroys the canvas that hides the board and the check button,
        when the timer ends it hides it again,asks the palyer if he would like to play a new game and
        '''
        self._sheet.destroy()
        self._hide_check_button2.destroy()

        self._countdown_button.destroy()
        if self._timer == 0:
            self._hide_check_button = tk.Canvas(self._right_frame,width=self.width_pr(15),height=self.height_pr(10),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
            self._hide_check_button.place(relx=0.3, rely=0.77, anchor="center")
            self._sheet_2 = tk.Canvas(self._center_frame,width=self.width_pr(50),height=self.height_pr(80),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
            self._sheet_2.pack()
            self._hide_timer = tk.Canvas(self._right_frame,width=self.width_pr(15),height=self.height_pr(10),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
            self._hide_timer.place(relx=0.3, rely=0.29, anchor="center")
            self._display_feedback_label["text"] = "NEW GAME?"
            self._hide_new_game.destroy()
           
        self._timer -= 1000
        self._countdown_timer_minutes["text"] = "0"+str(self._timer//60000)+":"
        if (self._timer%60000)//1000 < 10:
            self._countdown_timer_seconds["text"] = "0"+str((self._timer%60000)//1000)
        else:
            self._countdown_timer_seconds["text"] = str((self._timer%60000)//1000)
        self._main_window.after(1000, self._start_play)


    def run(self):
        '''
        a function that calls the main loop with thw main window
        '''
        self._main_window.mainloop()

    def _create_buttons_in_board(self):
        '''
        function calls the function randomize_board and creates a buttons using the grid() method, 
        each cell will have a string according to the strings in the randomized board 
        '''
        board = randomize_board()
        self._buttons=[[None for i in range(len(board[0]))] for line in range(len(board)+1)]
        self._pressed_buttons=[[False for i in range(len(board[0]))] for line in range(len(board))]

        for i in range(len(board)):
            tk.Grid.columnconfigure(self._board_label,i, weight = 1)
        for i in range(len(board[0])):
            tk.Grid.rowconfigure(self._board_label,i, weight = 1)
        for row in range(len(board)):
            for col in range(len(board[0])):
                self._make_button(board[row][col],row,col)
        self._buttons[4][0]=self._check_button

    def _make_button(self,button_char,row,col):
        '''
        creates a button and adds it to
        '''
        button = tk.Button(self._board_label,text = button_char,bg="peach puff",font=(MAIN_FONT,24),width=6,height=3,highlightbackground="maroon",highlightthickness=1)
        button.grid(row=row,column=col, sticky=tk.NSEW)
        self._buttons[row][col] = button


    def set_display(self , change_display_lst):
        '''
        gets a list of parameters to change on the screen and changes it according to the list
        "change_display_list" = [score,time,found_words,your_word,feedback]
        '''
        if change_display_lst[5]:
            self.call_new_game_gui()
        self._display_score_label["text"] = change_display_lst[0] 
        if change_display_lst[1] != []:
            self._words_list.insert("end",change_display_lst[1])
        self._display_word_label["text"] = change_display_lst [2]
        self._display_feedback_label["text"] = change_display_lst[3]
    def des_time(self):
            self._hide_timer.destroy()
            self._sheet_2.destroy()
            self._hide_check_button.destroy()


        
    def call_new_game_gui(self):
        '''
        calls this function when the player wants to start a new game, 
        the function updates the class parameters to their primary state
        '''
        self._display_score_label["text"] = 'YOUR SCORE: 0'
        self._timer = 181000
        self._words_list.delete(0,"end")
        self._display_word_label["text"] = "YOUR WORD: "
        self._hide_new_game = tk.Canvas(self._right_frame,width=self.width_pr(15),height=self.height_pr(10),bg=MAIN_COLOR,highlightbackground=MAIN_COLOR)
        self._hide_new_game.place(relx=0.3, rely=0.62, anchor="center")
        new_board= randomize_board()
        for i in range(len(new_board)):
            for j in range(len(new_board[0])):
                self._buttons[i][j]["text"] = new_board[i][j]
        self._main_window.after(1000, self.des_time)
        

    

    def set_button_command(self, button_loc, cmd):
        '''
        sets a command to a button
        '''
        self._buttons[button_loc[0]][button_loc[1]].configure(command=cmd)
        

    def get_buttons_locs(self): 
        '''
        returns a list with all the buttons in the display
        '''
        result_list = []
        for r in range(len(self._buttons)):
            for c in range(len(self._buttons[0])):
                if r == 4 and c == 0:
                    break
                str_val=self._buttons[r][c]["text"]
                result_list+=[(str_val,(r,c))]
        result_list+=[("check word",(4,0))]
        result_list+=[("YES",(4,1))]
        result_list+=[("NO",(4,2))]
        return result_list

