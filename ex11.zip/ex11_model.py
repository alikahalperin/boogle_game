from ex11_utils import*
from playsound import playsound


class BoggleModel:
    def __init__(self,words_dict) -> None:
        self._word_display ="YOUR WORD: "
        self._all_words_display=[]
        self._all_words_display_changed = False
        self._word_str = ""
        self._path = []
        self._words_dict = words_dict
        self._score = 0
        self._score_display = "YOUR SCORE: " + str(self._score)
        self._timer = 180
        self._first_time = True
        self._feedback = " "
        
    def start_new_game(self)-> None:
        '''
        calls this function when the player wants to start a new game, 
        the function updates the class parameters to their primary state
        '''
        self._word_display ="YOUR WORD: "
        self._words_dict.update(self._all_words_display)
        self._all_words_display=[]
        self._all_words_display_changed = False
        self._word_str = ""
        self._path = []
        self._score = 0
        self._score_display = "YOUR SCORE: " + str(self._score)
        self._timer = 180
        self._first_time = True
        self._feedback 

    def get_display(self,btn_tuple):
        '''
    This function returns the current display information for the game.
    
    Parameters:
    - btn_tuple (tuple): A tuple containing the button information for the game.
    
    Returns:
    - List[int,str,str,str,tuple(int,int),bool]: A list containing the following information:
        - dis_score (int): The current score of the game.
        - dis_words (List[str]): A list of all the words displayed in the game.
        - dis_word (str): The current word being displayed.
        - dis_feedback (str): Feedback on the current word being displayed.
        - dis_btn (tuple(int,int)): The button information passed in as a parameter.
        - is_new_game (bool): A flag indicating if a new game is being started.
        '''
        if btn_tuple == (4,1):
            is_new_game = True
            self._feedback = ""
        else:
            is_new_game = False
        dis_score = self._score_display
        if not self._all_words_display_changed:
            dis_words = []
        else:
            dis_words = self._all_words_display
            self._all_words_display_changed = False
        dis_word = self._word_display
        dis_feedback = self._feedback
        dis_btn = btn_tuple
        return [dis_score,dis_words,dis_word,dis_feedback,dis_btn,is_new_game]
    

    def type_in(self, cell) -> None: 
        '''
        checks which button was pressed:
        if it is the "check word": calls the check_word() function and the clear_word() function
        if the players yes button then is calls the start_new_game() function and if it was a letter it changes the display parameters
        '''
        #playsound('button_sound.mp3',block=False)
        if cell[0]=="YES":
            self.start_new_game()
        else:
            if cell[0] == "check word":
                self._check_word()
                self._clear_word()
            else: 
                if self._path==[]:
                    self._word_str+=cell[0]
                    self._path += [cell[1]]
                    self._word_display += cell[0]
                if cell[1] not in self._path and is_neighbor(self._path[-1],cell[1]):
                    self._word_str = self._word_str+cell[0]
                    self._path += [cell[1]]
                    self._word_display += cell[0]
                    
    def _check_word(self) -> bool:
        '''
        calls this function when "CHECK WORD" is pressed
        The function checks if the attribute "_word_str" of the object is in a list of words stored in an attribute "_words_dict". If it is, the attribute "_score" is incremented by the square of the length of the path stored in the attribute "_path". The attributes "_score_display", "_words_dict", "_all_words_display", and "_all_words_display_changed" are also updated. The method then returns True. 
        If the attribute "_word_str" is not in the list of words, the attribute "_feedback" is set to a string and the method returns False.
        '''
        if self._word_str in self._words_dict:
            self._score+=len(self._path)**2
            self._score_display = "YOUR SCORE: " + str(self._score)
            self._words_dict.remove(self._word_str)
            self._all_words_display=[self._word_str]
            self._all_words_display_changed = True
            self._feedback = "GREAT JOB"
            return True
        else :
            self._feedback = "YOU'RE A LOSER"
            return False

    def _clear_word(self):
        '''
        when the user pressed check button, cleans the display and the path of the last word
        '''
        self._word_display = "YOUR WORD: "
        self._word_str = ""
        self._path = []



    