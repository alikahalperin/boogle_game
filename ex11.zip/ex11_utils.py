from typing import List, Tuple, Iterable, Optional
import boggle_board_randomizer
Board = List[List[str]]
Path = List[Tuple[int, int]]
import copy
BOARD_SIZE = 4


def load_words_dict(file_name: str) -> set:
    """ 
    The function gets a string represents the filename and returns a set containing all the info of the file.
    """
    file_list = set(open(file_name).read().split())
    return file_list

def is_neighbor(loc1: tuple, loc2: tuple) -> bool:
    """ 
    The function gets two tuples and retuns if they are neighbors
    """
    if abs(loc1[0]-loc2[0])>=2 or abs(loc1[1]-loc2[1])>=2 or (loc1[0] == loc2[0] and loc1[1] == loc2[1]):
        return False
    return True

def loc_in_board(loc: tuple, board: Board) -> bool:
    """
    the function returns if a given location is in the board.
    """ 
    if 0<=loc[0]<len(board) and 0<=loc[1]<len(board[0]):
        return True
    return False

def is_valid_path(board: Board, path: Path, words: Iterable[str]) -> Optional[str]:
    """ 
    the function returns if the path is possible according to the rules.
    """
    word = ""
    for i in range(len(path)):
        if not loc_in_board(path[i],board): #if the location is not in board
            return
        elif i+1<len(path): #we already checked the last tuple
            if not is_neighbor(path[i],path[i+1]):
                return
        word += board[path[i][0]][path[i][1]] 
    if word in words:
        return word

def possible_neighbors(row, col):
    """
    the function returns a list of all the locations that surround a given location.
    """
    list_index = []
    if 0<=row-1 and 0<=col-1:
        list_index.append((row-1,col-1))
    if 0<=row-1:
        list_index.append((row-1,col))
    if 0<=row-1 and col+1<=3:
        list_index.append((row-1,col+1))
    if 0<=col-1:
        list_index.append((row,col-1))
    if col+1<=3:
        list_index.append((row,col+1))
    if row+1<=3 and 0<=col-1:
        list_index.append((row+1,col-1))
    if row+1<=3:
        list_index.append((row+1,col))
    if row+1<=3 and col+1<=3:
        list_index.append((row+1,col+1))
    return list_index

def change_bool_board(row, col, bool_board):
    """
    The function changes the boolean board according to where the backtrack was
    """
    if bool_board[row][col]:
        bool_board[row][col] = False
    else:
        bool_board[row][col] = True
    return bool_board



def filter_neighbors_func(board, bool_board, neighbors_list, word, str_ind):
    '''
    a function that gets a list of neighbors and returns a list of neighbors that contain the next letter in the word,
    if there are no such neighbors it returns an empty list
    #try and write it ufing filter
    '''
    filtered_neighbors_list = []
    for neighbor in neighbors_list:
        if list(board[neighbor[0]][neighbor[1]]) == word[str_ind[0]+1:str_ind[0]+len(board[neighbor[0]][neighbor[1]])+1]:
            if not bool_board[neighbor[0]][neighbor[1]]:
                    filtered_neighbors_list.append(neighbor)
    return filtered_neighbors_list
    

def find_paths_from_loc(row: int, col: int, word: str, found_word: str, board: Board, bool_board: List[List[bool]], result_list: List[List[tuple]], str_ind: int, res_list):
    '''
    the function returns all the paths of a given word from a location.
    '''
    if found_word == word[:-len(board[row][col])] and list(board[row][col]) == word[-len(board[row][col]):]:
        found_word.extend(list(board[row][col]))
        res_list.append((row,col))
        copied_res_list = copy.deepcopy(res_list)
        bool_board = change_bool_board(row, col, bool_board)
        if len(copied_res_list) == 1:
            return [copied_res_list]
        return copied_res_list
    found_word.extend(list(board[row][col]))
    res_list.append((row,col))
    bool_board = change_bool_board(row, col, bool_board)
    neighbors_list = possible_neighbors(row, col)
    filtered_neighbors_list = filter_neighbors_func(board, bool_board, neighbors_list, word, str_ind)
    if filtered_neighbors_list == []:
        bool_board = change_bool_board(row, col, bool_board)
        return None
    else:
        for neighbor in filtered_neighbors_list:
            str_ind[0]+=len(board[neighbor[0]][neighbor[1]])
            temp = find_paths_from_loc(neighbor[0], neighbor[1], word,found_word, board, bool_board, result_list, str_ind, res_list)
            if temp != None:
                bool_board = change_bool_board(neighbor[0], neighbor[1], bool_board)
            if temp != None and temp != result_list:
                result_list.append(temp)
            res_list.pop()
            str_ind[0]-=len(board[neighbor[0]][neighbor[1]])
            for i in range(len(board[neighbor[0]][neighbor[1]])):
                found_word.pop()
    return result_list


def find_paths_from_loc_max_score(row: int, col: int, word: str, found_word: str, board: Board, bool_board: List[List[bool]], result_list: List[List[tuple]], str_ind: int, res_list):
    '''
    the function returns all paths from a given location or the longest path. 
    '''
    if found_word == word[:-len(board[row][col])] and list(board[row][col]) == word[-len(board[row][col]):]:
        found_word.extend(list(board[row][col]))
        res_list.append((row,col))
        copied_res_list = copy.deepcopy(res_list)
        bool_board = change_bool_board(row, col, bool_board)
        if len(copied_res_list) == 1:
            return [copied_res_list]
        return copied_res_list
    found_word.extend(list(board[row][col]))
    res_list.append((row,col))
    bool_board = change_bool_board(row, col, bool_board)
    neighbors_list = possible_neighbors(row, col)
    filtered_neighbors_list = filter_neighbors_func(board, bool_board, neighbors_list, word, str_ind)
    if filtered_neighbors_list == []:
        bool_board = change_bool_board(row, col, bool_board)
        return None
    else:
        for neighbor in filtered_neighbors_list:
            str_ind[0]+=len(board[neighbor[0]][neighbor[1]])
            temp = find_paths_from_loc_max_score(neighbor[0], neighbor[1], word,found_word, board, bool_board, result_list, str_ind, res_list)
            if temp != None:
                bool_board = change_bool_board(neighbor[0], neighbor[1], bool_board)
            if temp != None and temp != result_list:
                result_list.append(temp)
            res_list.pop()
            str_ind[0]-=len(board[neighbor[0]][neighbor[1]])
            if result_list != []:
                for l in result_list:
                    if len(l) == len(word):
                        return result_list
            for i in range(len(board[neighbor[0]][neighbor[1]])):
                found_word.pop()
    return result_list


def find_all_paths(word, board):
    """
    the function returns all the paths of a given word.
    """
    result_list = []
    for row in range(BOARD_SIZE):
        for col in range(BOARD_SIZE):
            if board[row][col] == word[0:len(board[row][col])]:   
                bool_board = [[False for i in range(BOARD_SIZE)] for j in range(BOARD_SIZE)]
                returned_list = find_paths_from_loc(row,col,list(word),[], board,bool_board,[],[len(board[row][col])-1],[]) 
                if returned_list != None:
                    result_list+=returned_list
    return result_list

def find_all_paths_max_score(word, board):
    """
    the funcion returns all the paths of a given word or the longest path.
    """
    result_list = []
    for row in range(BOARD_SIZE):
        for col in range(BOARD_SIZE):
            if board[row][col] == word[0:len(board[row][col])]:   
                bool_board = [[False for i in range(BOARD_SIZE)] for j in range(BOARD_SIZE)]
                returned_list = find_paths_from_loc_max_score(row,col,list(word),[], board,bool_board,[],[len(board[row][col])-1],[]) 
                if returned_list != None:
                    for path in returned_list:
                        if len(path) == len(word):
                            return [path]
                    result_list+=returned_list
    return result_list



def find_length_n_paths(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    '''
    the function returns all paths len n of all the words.
    '''
    list_of_paths = []
    words_set = set(filter(lambda word: n<=len(word)<=2*n, words))
    for word in words_set:
        small_list_of_paths = find_all_paths(word, board)
        for path in small_list_of_paths:
            if len(path) == n:
                list_of_paths.append(path)
    return list_of_paths

def find_length_n_words(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    '''
    the function returns all the paths of a given word.
    '''    
    list_of_paths = []
    words_set_len_n = set(filter(lambda word: len(word)==n, words)) #the set contains only words in len 'n'
    for word_len_n in words_set_len_n:
        list_of_paths += find_all_paths(word_len_n, board)
    return list_of_paths


def max_score_paths(board: Board, words: Iterable[str]) -> List[Path]:
    """
        the function gets a dictionary of words and a board and returns the maximum score that can be achived from this board
        EXAMPLE: for the word "NIGHT" the best path is with length 5(the word length) and the score is 25 
        and the worst path it 3 ("NI"+"GH"+"T") (half the word +1)    """
    list_max_score = []
    words_added = set()
    temp_dict = set() 
    for word in words: #go throgh the words in the dictionary
        #print(find_length_n_paths(2,board6,word)) for word in words: #go throgh the words in the dictionary
        temp_dict=set()
        for n in range(len(word),(len(word)//2)-1,-1): #in the given exapmle the loop goes from 5 to 3 
            temp_dict.add(word) 
            all_paths_list = find_all_paths_max_score(word, board) #find the paths of the word with the length n
            if all_paths_list!=[]: 
                if word not in words_added:
                    words_added.add(word)
                    list_max_score.append(all_paths_list[0])
        #continue looking for the best route
#didnt find any routes, continue to the next word
    return list_max_score


